#! /usr/bin/env python3
# -*- coding: utf-8 -*-
#

# CALFILE must be writable by ftc user

import sys, os, subprocess,time

CALFILE="/usr/share/X11/xorg.conf.d/99-calibration.conf"

if __name__ == "__main__":
    # this will only be used on the TX-Pi running a real X servern and never
    # on a TXT. So we don't need a Qt fake window   
    p = subprocess.Popen(["xinput_calibrator"], stdout=subprocess.PIPE)
    result = p.communicate()[0].decode("utf-8")

    strings = result.split("\n")
    begin = -1
    idx = 0
    for s in strings:
        if s.startswith("Section"):
            begin = idx
        idx = idx + 1

    if idx > 0:        
        cal = "\n".join(strings[begin:])
        with open(CALFILE, "w") as f: 
            f.write(cal) 
    
        # reboot to use new settings
        subprocess.Popen(["sudo", "reboot"])
